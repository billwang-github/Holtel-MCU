/*	Panel with 3 digits 7-segment, 6 function key, EEPROM R/W with UART interfac
**	Written by Bill Wang@GMT 2018/10/23
*/
#include "HT66F319.h"

#define uint8_t unsigned char
#define uint16_t unsigned short
#define uint32_t unsigned long

uint8_t buff_ee[16];

void Init_System(void);
uint8_t EE_Write_Byte(uint8_t addr, uint8_t data);
uint8_t EE_Read_Byte(uint8_t addr);

void main()
{	
	uint8_t  i;
	
	Init_System();			

/*==== EEPROM write test ====*/	
	for (i = 0; i < 7; i++)
	{
		EE_Write_Byte(i, 0xE0+i);
	}
	
	for (i = 0; i < 7; i++)
	{
		buff_ee[i] = EE_Read_Byte(i);
	}

	GCC_NOP();
					
	while (1)
	{	
		GCC_CLRWDT();		
	}
}

void Init_System(void)
{	
	_acerl = 0x00; //disable ADC
	_cos = 1; //CX disabled
	_csel = 0; // disable C+, C-
}

uint8_t EE_Write_Byte(uint8_t addr, uint8_t data)  // please add 1ms delay after next write
{
	
	_eea = addr;
	_eed = data;
	_mp1 = 0x40; //EEC control register is located at address 40H in Bank 1
	_bp = 0x01;
	_emi = 0;
	_iar1 |= 0x08; //WREN
	_iar1 |= 0x04; //WR
	_emi =1;
	while ((_iar1 & 0x04) == 0x04) // check if write cycle finished
	{
		GCC_CLRWDT();
	}
	_iar1 = 0;
	_bp = 0;
	return 1;	
}

uint8_t EE_Read_Byte(uint8_t addr)
{
	_eea = addr;
	_mp1 = 0x40; //EEC control register is located at address 40H in Bank 1
	_bp = 0x01;
	_emi = 0;
	_iar1 |= 0x02; //RDEN
	_iar1 |= 0x01; //RD
	_emi =1;
	while ((_iar1 & 0x01) == 0x01) // check if write cycle finished
	{
		GCC_CLRWDT();
	}
	_iar1 = 0;
	_bp = 0;
	return _eed;
}	

